﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SemenApp
{
    internal class MainFrm
    {
        public static Frame MainFrame { get; set; }
        public static MainWindow MainWindowInstance { get; set; }
    }
}
