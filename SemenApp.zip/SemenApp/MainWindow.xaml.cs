﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SemenApp.Pages;

namespace SemenApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string captchaText;
        public static class NavigationHelper
        {
            public static Frame MainFrame { get; set; }
            public static MainWindow MainWindowInstance { get; set; }
        }

        public MainWindow()
        {
            InitializeComponent();
            GenerateCaptcha();
            DisplayCaptchaText();
            MainFrm.MainFrame = mainFrame;
            NavigationHelper.MainWindowInstance = this;
        }
        public Label MyLabel => lblma;

        private const string ConnectionString = "Data Source=DESKTOP-12AD13T\\MSSQLSERVERONE; Initial Catalog=SemenAppDB;Integrated Security=True";

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            string login = loginBox.Text;
            string password = passwordtBox.Password;
            string testPassword = passwordTestBox.Password;

            // Проверка наличия логина и паролей
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(testPassword))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            // Проверка совпадения паролей
            if (!string.Equals(password, testPassword, StringComparison.Ordinal))
            {
                MessageBox.Show("Пароли не совпадают!");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Users (login, password) VALUES (@login, @password)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@login", login);
                        command.Parameters.AddWithValue("@password", password);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Вы зарегистрированы!");

                        mainFrame.Navigate(new AuthPage());
                        lblma.Content = "Авторизация";
                        AuthBtn.Visibility = Visibility.Hidden;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }


        private void GenerateCaptcha()
        {
            // Генерация случайного текста для капчи
            captchaText = GenerateRandomText();
        }

        private string GenerateRandomText()
        {
            // Пример генерации случайного текста (ваша логика здесь)
            Random random = new Random();
            return random.Next(1000, 9999).ToString();
        }

        private void DisplayCaptchaText()
        {
            // Отображение текста капчи в TextBlock
            captchaTextBlock.Text = captchaText;
        }

        private void CheckCaptcha_Click(object sender, RoutedEventArgs e)
        {
            // Логика проверки введенного текста с капчи
            string enteredText = captchaTextBox.Text;

            if (enteredText.Equals(captchaText, StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Проверка пройдена!");
                btnReg.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Неправильный текст капчи. Попробуйте снова.");
                GenerateCaptcha();
                DisplayCaptchaText();
            }
        }

        private void mainFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void Auth_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.Navigate(new AuthPage());
            lblma.Content = "Авторизация";
            AuthBtn.Visibility = Visibility.Hidden;

        }
    }
}
