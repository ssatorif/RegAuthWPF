﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SemenApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для Data.xaml
    /// </summary>
    public partial class Data : Page
    {
        public ObservableCollection<Users> Users { get; set; }
        public Data()
        {
            InitializeComponent();
            Users = new ObservableCollection<Users>();
            LoadDataFromDatabase();
        }
        private const string ConnectionString = "Data Source=DESKTOP-12AD13T\\MSSQLSERVERONE; Initial Catalog=SemenAppDB;Integrated Security=True";

        private void LoadDataFromDatabase()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM Users";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Users user = new Users
                                {
                                    id_user = reader.GetInt32(0),
                                    login = reader.GetString(1),
                                    password = reader.GetString(2)
                                   
                                };

                                Users.Add(user);
                            }
                        }
                    }
                }

                // привязка к дата гриду
                dataGrid.ItemsSource = Users;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }
    }
}
 