﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SemenApp.Pages;

namespace SemenApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public static class NavigationHelper
        {
            public static Frame MainFrame { get; set; }
            public static MainWindow MainWindowInstance { get; set; }
        }
        private string captchaText;
         
        public AuthPage()
        {
            InitializeComponent();
            GenerateCaptcha();
            GenerateRandomText();
            DisplayCaptchaText();

           

        }
        private const string ConnectionString = "Data Source=DESKTOP-12AD13T\\MSSQLSERVERONE; Initial Catalog=SemenAppDB;Integrated Security=True";
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = loginBox.Text;
            string password = passwordtBox.Password;

            // Проверка наличия логина и пароля
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    string query = "SELECT COUNT(1) FROM Users WHERE login = @login AND password = @password";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@login", login);
                        command.Parameters.AddWithValue("@password", password);

                        int count = (int)command.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("Авторизация успешна!");

                            NavigationService.Navigate(new Data());

                            if (NavigationHelper.MainWindowInstance != null)
                            {
                                Label mainWindowLabel = NavigationHelper.MainWindowInstance.MyLabel;
                                NavigationHelper.MainWindowInstance.lblma.Content = "Данные";
                            }
                           

                        }
                        else
                        {
                            MessageBox.Show("Неверный логин или пароль. Попробуйте еще раз.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
        private void GenerateCaptcha()
        {
            // Генерация случайного текста для капчи
            captchaText = GenerateRandomText();
        }

        private string GenerateRandomText()
        {
            // Пример генерации случайного текста (ваша логика здесь)
            Random random = new Random();
            return random.Next(1000, 9999).ToString();
        }

        private void DisplayCaptchaText()
        {
            // Отображение текста капчи в TextBlock
            captchaTextBlock.Text = captchaText;
        }

        private void CheckCaptcha_Click(object sender, RoutedEventArgs e)
        {
            // Логика проверки введенного текста с капчи
            string enteredText = captchaTextBox.Text;

            if (enteredText.Equals(captchaText, StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("Проверка пройдена!");
                btnReg.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Неправильный текст капчи. Попробуйте снова.");
                GenerateCaptcha();
                DisplayCaptchaText();
            }
        }
    }
}
